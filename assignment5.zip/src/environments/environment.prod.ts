export const environment = {
  production: true,
  clientID: "219db059664745e69566154b28f40362",
  clientSecret: "ba0da086ce034b42962dfcbcfb4896fc"
};
